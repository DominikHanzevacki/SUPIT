/*Kontakt */
document.querySelector(".close").addEventListener('click',
    function () {
        document.querySelector(".Kontakt_Obrazac").style.display = "none";
    });

document.getElementById("button5").addEventListener('click',
    function () {
        document.getElementById("Kontakt_Obrazac").style.display = "flex";
    });



/*O_Nama*/
$(document).ready(function () {
    $(".Button2").click(function () {
        $(".O_nama_header_img").slideDown();
    });
    $("#Button2").click(function () {
        $(".O_nama_header").slideUp();
    });
});
/*Nastavni Plan*/
/*Ucitavanje Liste*/
$("#Tablica_Kolegiji").hide();   

function Prikaz_Tablice() 
{
    $("#Tablica_Kolegiji").show();

}
var Kolegiji = [];
var Kolegij_label = [];
$.get('http://www.fulek.com/VUA/SUPIT/GetNastavniPlan').done((data) => data.forEach(function (name) {
    Kolegiji.push(name);
    Kolegij_label.push(name.label);
}),
);
console.log(Kolegiji);
/*Pretraga Liste */
var Kolegiji_u_tablici = [];
$(function () {
    $('#Pretraga_Kolegija').autocomplete({
        source: Kolegij_label,
        select: function (event, label) {
            var kolegij_url = 'http://www.fulek.com/VUA/supit/GetKolegij/';
            var kolegij_value;
            Kolegiji.forEach(element => {
                if (element.label == label.item.label) {
                    kolegij_value = element.value;
                    console.log(element);
                }
            });
           
            var kolegij;
            $.ajax({
                async: false,
                url: kolegij_url + kolegij_value,
                dataType: 'JSON',
                success: function (json) {
                    kolegij = json;
                    console.log(kolegij);
                }
            });
            Prikaz_Tablice() 
                Kolegiji_u_tablici.push(kolegij);
                var tablica = document.getElementById("Tablica_Kolegiji");
                var redak = tablica.insertRow(Kolegiji_u_tablici.length);
                var cell1 = redak.insertCell(0);
                var cell2 = redak.insertCell(1);
                var cell3 = redak.insertCell(2);
                var cell4 = redak.insertCell(3);
                var cell5 = redak.insertCell(4);
                var cell6 = redak.insertCell(5);
                var cell7 = redak.insertCell(6);
                var button = document.createElement('button');
                button.setAttribute('value', 'Obrisi');
                button.setAttribute('id', kolegij.kolegij + 'Button');
                button.setAttribute('class', 'Brisi_button');
                button.innerHTML = 'Obrisi';
                cell1.innerHTML = kolegij.kolegij;
                cell2.innerHTML = kolegij.ects;
                cell3.innerHTML = kolegij.sati;
                cell4.innerHTML = kolegij.predavanja;
                cell5.innerHTML = kolegij.vjezbe;
                cell6.innerHTML = kolegij.tip;
                cell7.appendChild(button);
                Zbroji();
                Obrisi(button,kolegij);
                
        }
    });
});
function Zbroji() {
    var Ukupno_ects = document.getElementById('Ukupno_Ects');
            var Ukupno_sati = document.getElementById('Ukupno_Sati');
            let zbroj_ects = 0;
            let zbroj_sati = 0;
            Kolegiji_u_tablici.forEach(element => {
                zbroj_ects += element.ects;
                zbroj_sati += element.sati;
            });
            Ukupno_ects.innerHTML = zbroj_ects;
            Ukupno_sati.innerHTML = zbroj_sati;
            if (zbroj_sati == 0) {
                $("#Tablica_Kolegiji").hide(); 
            }
}
function Obrisi(button,kolegij) {
    $(button).click(function () {
        $(this).closest("tr").remove();
        for( var i = 0; i < Kolegiji_u_tablici.length; i++){ 
            if ( Kolegiji_u_tablici[i] == kolegij) {
              Kolegiji_u_tablici.splice(i, 1); 
            }
         }
         Zbroji();
    });
}
